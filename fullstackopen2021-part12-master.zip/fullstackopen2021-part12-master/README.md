# Full Stack 2021 - Part 12 | Containers
University of Helsinki - Full Stack 2021 - Part 12 course exercise submissions

## Certificate of Completion

https://studies.cs.helsinki.fi/stats/api/certificate/fs-containers/en/32731e8411572ac521707b5d28bb57f6

![Image of Certificate](https://studies.cs.helsinki.fi/stats/api/certificate/fs-containers/en/32731e8411572ac521707b5d28bb57f6)
